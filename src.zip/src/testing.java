public class testing {
    public static void main(String[]args){
        System.out.println("gay sex");
        System.out.println("there once was a chinese restaurant");
        System.out.println("and i bought i loaf of bread");
        System.out.println("the waiter didn't know my name");
        System.out.println("dylan is the big gay");
        System.out.println("MY DAD IS A MOM");

    }
    public static int difference(int num1, int num2){
        return num1-num2;
    }
    public static double division(double num1 , double num2){
        return num1/num2;
    }

}
